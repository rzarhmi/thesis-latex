# Thesis Template
A LaTeX template for typesetting theses in Persian
